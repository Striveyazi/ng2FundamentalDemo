import { Component,ViewEncapsulation } from '@angular/core';

@Component({
    selector:'left-expand',
    encapsulation:ViewEncapsulation.None,
    template:`
        <div>
            <div>左部拓展<div>
        </div>
    `
})
export class LeftExpand {

}
import { Component,ViewEncapsulation } from '@angular/core';

@Component({
    selector:'left-slider',
    encapsulation:ViewEncapsulation.None,
    template:`
        <div>
            <div>滑块<div>
        </div>
    `
})
export class LeftSlider {

}
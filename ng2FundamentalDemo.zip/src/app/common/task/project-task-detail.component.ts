import { Component } from '@angular/core';

@Component({
  templateUrl:'../../../assets/view/common/task/task-detail.html'  
})
/* 三级组件 */
export class ProjectTaskDetalComponent { }
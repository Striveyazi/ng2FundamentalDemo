import { Component } from '@angular/core';

@Component({
  template: `
  <div>
    <p>项目Bug板</p>
  </div>
  `
})
/* 三级组件 */
export class ProjectBugsComponent { }
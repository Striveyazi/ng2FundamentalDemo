import { Component } from '@angular/core';

@Component({
  template: `
  <div>
    <p>项目成员板</p>
  </div>
  `
})
/* 三级组件 */
export class ProjectMemberComponent { }
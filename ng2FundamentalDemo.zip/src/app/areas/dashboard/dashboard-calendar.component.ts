import { Component } from '@angular/core';

@Component({
  template: `
  <div>
    <p>日历</p>
  </div>
  `
})
export class DashBoardCalendarComponent { }
import { Component } from '@angular/core';

@Component({
  template: `
    <p>笔记</p>
  `
})
export class DashBoardNoteComponent { }